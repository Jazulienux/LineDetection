#!/usr/bin/env python
import rospy
from std_msgs.msg import Int16
from std_msgs.msg import Int32
import random as rd
import cv2
import numpy as np


if __name__ == "__main__":
	lowerBound=np.array([0,125,188])
	upperBound=np.array([25,255,255])
	#lowerBound=np.array([0,221,134])
	#upperBound=np.array([26,255,255])
	cam= cv2.VideoCapture(6)
	cam.set(cv2.CAP_PROP_AUTO_EXPOSURE,0.0)
	rospy.init_node('camera_data')
	pub = rospy.Publisher('camera_x', Int16, queue_size=10)
	pub1 = rospy.Publisher('camera_y', Int16, queue_size=10)
	pub2 = rospy.Publisher('depth', Int16, queue_size=10)
	pub3 = rospy.Publisher('random_number', Int32, queue_size=10)
	try:
		while not rospy.is_shutdown():
			num = rd.randint(0,100)
			ret, img=cam.read()
			img=cv2.resize(img,(340,250))
			#convert BGR to HSV
			blurr=cv2.GaussianBlur(img,(11,11),0)
			#blurr=cv2.blur(img,(11,11))
			#blurr=cv2.bilateralFilter(img,11,11,0)
			imgHSV= cv2.cvtColor(blurr,cv2.COLOR_BGR2HSV)
			# create the Mask
			mask=cv2.inRange(imgHSV,lowerBound,upperBound)
			mask=cv2.erode(mask,None,iterations=6)
			mask=cv2.dilate(mask,None,iterations=6) 
			#(_,conts,_)=cv2.findContours(maskFinal.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
			(_,conts,_)=cv2.findContours(mask.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
			
			#cv2.drawContours(img,conts,-1,(255,0,0),3)
			for i in range(len(conts)):
				(x,y),radius = cv2.minEnclosingCircle(conts[i])
				center = (int(x),int(y))
				radius = int(radius)
				bola = cv2.circle(img,center,radius,(0,0,255),2)
				M = cv2.moments(conts[i])
				x = int(M['m10']/M['m00'])
				y = int(M['m01']/M['m00'])
        
				print (x,y,radius,num)
				pub.publish(x)
				pub1.publish(y)
				pub2.publish(radius)
				pub3.publish(num)
			#cv2.imshow("cam",img)
			cv2.waitKey(10)
	except rospy.ROSInterruptException:
		pass
